package selectpage;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.GridLayout;

public class selectpage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					selectpage frame = new selectpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public selectpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JLabel lblPleaseSelectThe = new JLabel("Please select the room type");
		lblPleaseSelectThe.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblPleaseSelectThe, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.WEST);
		panel.setLayout(new GridLayout(5, 1, 10, 10));
		
		JLabel lblClassicTpye = new JLabel("classic tpye");
		panel.add(lblClassicTpye);
		
		JLabel lblSingleRoom = new JLabel("single room");
		panel.add(lblSingleRoom);
		
		JLabel lblLuxerySingleRoom = new JLabel("luxery single room");
		panel.add(lblLuxerySingleRoom);
		
		JLabel lblSuiteRoom = new JLabel("suite room");
		panel.add(lblSuiteRoom);
		
		JLabel label = new JLabel("");
		panel.add(label);
	}

}
