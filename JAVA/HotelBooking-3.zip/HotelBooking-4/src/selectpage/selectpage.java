package selectpage;

import java.awt.*;
import javax.swing.*;


public class selectpage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	ImageIcon room1=new ImageIcon("room1.jpg");
	ImageIcon room2=new ImageIcon("room2.jpg");
	ImageIcon room3=new ImageIcon("room3.jpg");
	ImageIcon room4=new ImageIcon("room4.jpg");
	/*room1.setImage(room1.getImage().getScaledInstance(40,20,Image.SCALE_DEFAULT));
	room2.setImage(room2.getImage().getScaledInstance(40,20,Image.SCALE_DEFAULT));
	room3.setImage(room3.getImage().getScaledInstance(40,20,Image.SCALE_DEFAULT));
	room4.setImage(room4.getImage().getScaledInstance(40,20,Image.SCALE_DEFAULT));
*/
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					selectpage frame = new selectpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public selectpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 749, 551);
		contentPane = new JPanel();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JLabel lblPleaseSelectThe = new JLabel("Please select the room type");
		lblPleaseSelectThe.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblPleaseSelectThe, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.WEST);
		panel.setLayout(new GridLayout(5, 1, 10, 10));
		
		JLabel lblClassicTpye = new JLabel("Standard Room");
		panel.add(lblClassicTpye);
		
		JLabel lblSingleRoom = new JLabel("single room");
		panel.add(lblSingleRoom);
		
		JLabel lblLuxerySingleRoom = new JLabel("deluxe single room");
		panel.add(lblLuxerySingleRoom);
		
		JLabel lblSuiteRoom = new JLabel("suite room");
		panel.add(lblSuiteRoom);
		
		JLabel label = new JLabel("");
		panel.add(label);
		
		JScrollBar scrollBar = new JScrollBar();
		contentPane.add(scrollBar, BorderLayout.EAST);
		
		JButton btnCheckOut = new JButton("CHECK OUT");
		contentPane.add(btnCheckOut, BorderLayout.SOUTH);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{142, 41, 41, 41, 41, 0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JLabel lblRoom = new JLabel(room1);
		GridBagConstraints gbc_lblRoom = new GridBagConstraints();
		gbc_lblRoom.anchor = GridBagConstraints.NORTHWEST;
		gbc_lblRoom.insets = new Insets(0, 0, 5, 5);
		gbc_lblRoom.gridx = 1;
		gbc_lblRoom.gridy = 0;
		panel_1.add(lblRoom, gbc_lblRoom);
		
		JLabel lblNumber = new JLabel("number");
		GridBagConstraints gbc_lblNumber = new GridBagConstraints();
		gbc_lblNumber.insets = new Insets(0, 0, 5, 5);
		gbc_lblNumber.gridx = 5;
		gbc_lblNumber.gridy = 0;
		panel_1.add(lblNumber, gbc_lblNumber);
		
		JButton button = new JButton("+");
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 5);
		gbc_button.gridx = 4;
		gbc_button.gridy = 3;
		panel_1.add(button, gbc_button);
		
		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 5;
		gbc_textField.gridy = 3;
		panel_1.add(textField, gbc_textField);
		textField.setColumns(10);
		
		JButton button_4 = new JButton("-");
		GridBagConstraints gbc_button_4 = new GridBagConstraints();
		gbc_button_4.insets = new Insets(0, 0, 5, 0);
		gbc_button_4.gridx = 6;
		gbc_button_4.gridy = 3;
		panel_1.add(button_4, gbc_button_4);
		
		JLabel lblRoom_1 = new JLabel(room2);
		GridBagConstraints gbc_lblRoom_1 = new GridBagConstraints();
		gbc_lblRoom_1.anchor = GridBagConstraints.NORTHWEST;
		gbc_lblRoom_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblRoom_1.gridx = 1;
		gbc_lblRoom_1.gridy = 7;
		panel_1.add(lblRoom_1, gbc_lblRoom_1);
		
		JButton button_1 = new JButton("+");
		GridBagConstraints gbc_button_1 = new GridBagConstraints();
		gbc_button_1.insets = new Insets(0, 0, 5, 5);
		gbc_button_1.gridx = 4;
		gbc_button_1.gridy = 7;
		panel_1.add(button_1, gbc_button_1);
		
		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 5;
		gbc_textField_1.gridy = 7;
		panel_1.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);
		
		JButton button_5 = new JButton("-");
		GridBagConstraints gbc_button_5 = new GridBagConstraints();
		gbc_button_5.insets = new Insets(0, 0, 5, 0);
		gbc_button_5.gridx = 6;
		gbc_button_5.gridy = 7;
		panel_1.add(button_5, gbc_button_5);
		
		JButton button_2 = new JButton("+");
		GridBagConstraints gbc_button_2 = new GridBagConstraints();
		gbc_button_2.insets = new Insets(0, 0, 5, 5);
		gbc_button_2.gridx = 4;
		gbc_button_2.gridy = 10;
		panel_1.add(button_2, gbc_button_2);
		
		textField_2 = new JTextField();
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.insets = new Insets(0, 0, 5, 5);
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.gridx = 5;
		gbc_textField_2.gridy = 10;
		panel_1.add(textField_2, gbc_textField_2);
		textField_2.setColumns(10);
		
		JButton button_6 = new JButton("-");
		GridBagConstraints gbc_button_6 = new GridBagConstraints();
		gbc_button_6.insets = new Insets(0, 0, 5, 0);
		gbc_button_6.gridx = 6;
		gbc_button_6.gridy = 10;
		panel_1.add(button_6, gbc_button_6);
		
		JLabel lblRoom_2 = new JLabel(room3);
		GridBagConstraints gbc_lblRoom_2 = new GridBagConstraints();
		gbc_lblRoom_2.anchor = GridBagConstraints.NORTHWEST;
		gbc_lblRoom_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblRoom_2.gridx = 1;
		gbc_lblRoom_2.gridy = 12;
		panel_1.add(lblRoom_2, gbc_lblRoom_2);
		
		JButton button_3 = new JButton("+");
		GridBagConstraints gbc_button_3 = new GridBagConstraints();
		gbc_button_3.insets = new Insets(0, 0, 5, 5);
		gbc_button_3.gridx = 4;
		gbc_button_3.gridy = 14;
		panel_1.add(button_3, gbc_button_3);
		
		textField_3 = new JTextField();
		GridBagConstraints gbc_textField_3 = new GridBagConstraints();
		gbc_textField_3.insets = new Insets(0, 0, 5, 5);
		gbc_textField_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_3.gridx = 5;
		gbc_textField_3.gridy = 14;
		panel_1.add(textField_3, gbc_textField_3);
		textField_3.setColumns(10);
		
		JButton button_7 = new JButton("-");
		GridBagConstraints gbc_button_7 = new GridBagConstraints();
		gbc_button_7.insets = new Insets(0, 0, 5, 0);
		gbc_button_7.gridx = 6;
		gbc_button_7.gridy = 14;
		panel_1.add(button_7, gbc_button_7);
		
		JLabel lblRoom_3 = new JLabel(room4);
		GridBagConstraints gbc_lblRoom_3 = new GridBagConstraints();
		gbc_lblRoom_3.insets = new Insets(0, 0, 0, 5);
		gbc_lblRoom_3.anchor = GridBagConstraints.NORTHWEST;
		gbc_lblRoom_3.gridx = 1;
		gbc_lblRoom_3.gridy = 16;
		panel_1.add(lblRoom_3, gbc_lblRoom_3);
	}

}
