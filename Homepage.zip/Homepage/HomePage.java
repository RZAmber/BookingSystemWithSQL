package Homepage; 
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
 
 
 
public class HomePage extends JFrame{ 
	private String[] hotel_info= new String[]{"Contact information","Tel: (201)586-9124","Email: hello_world_hotle@gmail.com"}; 
	private int mapX=400; 
	private int mapY=200; 
	public JTextField f2;
	public JTextField f3;
	public HomePage homepage;
	public String s;
	public String s1;
 
	public HomePage(){ 
 	//Whole windows 
 		super("HOTEL BOOKING SYSTEM"); 
 		Container c=getContentPane(); 
 		c.setLayout(new BorderLayout()); 
 		ImageIcon bg=new ImageIcon("building.jpg"); 
 		JLabel l=new JLabel(bg); 
 		l.setBounds(0,0,bg.getIconWidth(),bg.getIconHeight()); 
 		getLayeredPane().add(l,new Integer(Integer.MIN_VALUE)); 
 		((JPanel) c).setOpaque(false); 
 		
 		
 		//Title panel 
 		JPanel p1=new JPanel(); 
 		p1.setOpaque(false); 
 		JLabel label1=new JLabel("WELCOME TO HELLO WORLD HOTLE !"); 
 		label1.setForeground(Color.WHITE); 
 		label1.setFont(new Font("Zapfino", Font.BOLD,26)); 
 		p1.add(label1); 
 		c.add(BorderLayout.NORTH,p1); 
 	 
 	 
 	 
 		//user Operation panel 
 		JPanel p2=new JPanel(); 
 		p2.setOpaque(false); 
 		p2.setLayout(new FlowLayout(FlowLayout.CENTER,20,0)); 
 		// after user setting the date the font color turn black 
 		JTextField f1=new JTextField("Please choose Location",15); 
 		f1.setForeground(Color.LIGHT_GRAY); 
 		JTextField f2=new JTextField("Check in date",15); 
 		f2.setForeground(Color.LIGHT_GRAY); 
 		JTextField f3=new JTextField("Check out date",15); 
 		f3.setForeground(Color.LIGHT_GRAY); 
 		
 		Document doc = f2.getDocument();
 		doc.addDocumentListener(new DocumentListener(){
 			
 			public void insertUpdate(DocumentEvent e){
 				Document doc = e.getDocument();
 				try {
					String s = doc.getText(0, doc.getLength());
				} catch (BadLocationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
 			}
			
			@Override
			public void changedUpdate(DocumentEvent arg0) {
				
			}

			@Override
			public void removeUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				
			}
 		});
 		
 		Document doc1 = f3.getDocument();
 		doc.addDocumentListener(new DocumentListener(){
 			public void insertUpdate(DocumentEvent e){
 				Document doc1 = e.getDocument();
 				try {
 					String s1 = doc1.getText(0, doc.getLength());
 				} catch (BadLocationException e2) {
 					e2.printStackTrace();
 				}
 			}

			@Override
			public void changedUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}
 		});
 		
 		
 		JComboBox s1=new JComboBox(); 
 		s1.setMaximumRowCount(2);
 		s1.addItem("Please Choose");
 		s1.addItem("Hoboken");
 		
 		s1.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				String Location = (String)s1.getSelectedItem();
 				if(Location.equals("Hoboken")){
 					f1.setText("Hoboken");
 					f1.setForeground(Color.BLACK);
 				}
 				else if(Location.equals("Please Choose")){
 					f1.setText("Please Choose");
 					f1.setForeground(Color.BLACK);
 				}
 			}
 		});
 		
 		JComboBox s21=new JComboBox(); 
 		s21.addItem("Year");
 		for (int i = 2016; i <= 2050; i++)
 			s21.addItem(i);
 		JComboBox s22 = new JComboBox();
 		s22.addItem("Month");
 		for (int i = 1; i <= 12; i++)
 			s22.addItem(i);
 		JComboBox s23 = new JComboBox();
 		s23.addItem("Day");
 		for (int i = 1; i <= 31; i++)
 			s23.addItem(i);
 		s21.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				f2.setText(s21.getSelectedItem() + " " + s22.getSelectedItem()+ " " +s23.getSelectedItem());
 				f2.setForeground(Color.BLACK);
 			}
 		});
 		s22.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				f2.setText(s21.getSelectedItem() + " " + s22.getSelectedItem()+ " " +s23.getSelectedItem());
 				f2.setForeground(Color.BLACK);
 			}
 		});
 		s23.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				f2.setText(s21.getSelectedItem() + " " + s22.getSelectedItem()+ " " +s23.getSelectedItem());
 				f2.setForeground(Color.BLACK);
 			}
 		});
 	   
 		
 		JComboBox s31=new JComboBox(); 
 		s31.addItem("Year");
 		for (int i = 2016; i <= 2050; i++)
 			s31.addItem(i);
 		JComboBox s32 = new JComboBox();
 		s32.addItem("Month");
 		for (int i = 1; i <= 12; i++)
 			s32.addItem(i);
 		JComboBox s33 = new JComboBox();
 		s33.addItem("Day");
 		for (int i = 1; i <= 31; i++)
 			s33.addItem(i);
 		s31.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				f3.setText(s31.getSelectedItem() + " " + s32.getSelectedItem() + " " + s33.getSelectedItem());
 				f3.setForeground(Color.BLACK);
 			}
 		});
 		s32.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				f3.setText(s31.getSelectedItem() + " " + s32.getSelectedItem() + " " + s33.getSelectedItem());
 				f3.setForeground(Color.BLACK);
 			}
 		});
 		s33.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				f3.setText(s31.getSelectedItem() + " " + s32.getSelectedItem() + " " + s33.getSelectedItem());
 				f3.setForeground(Color.BLACK);
 			}
 		});
 		JButton b1=new JButton("OK"); 
 		b1.addActionListener(new ActionListener(){
 			public void actionPerformed(ActionEvent e){
 				
 				selectpage SelectPage = new selectpage();
 				SelectPage.setSize(1000,750);
 				SelectPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 				SelectPage.setVisible(true);
 				//homepage.setVisible(false);
 			}
 		});
 		
 		
 		
 		p2.add(f1); 
 		p2.add(s1); 
 		p2.add(f2); 
 		p2.add(s21); 
 		p2.add(s22);
 		p2.add(s23);
 		p2.add(f3); 
 		p2.add(s31); 
 		p2.add(s32);
 		p2.add(s33);
 		p2.add(b1); 
 		c.add(BorderLayout.CENTER,p2); 
 		
 		//information panel 
 		JPanel p3=new JPanel(); 
 		p3.setOpaque(false); 
 		p3.setBackground(Color.blue); 
 		p3.setLayout(new FlowLayout()); 
 	 
	 
 		JPanel subp1 = new JPanel();  
 		subp1.setOpaque(false); 
 		ImageIcon map =new ImageIcon("map.png"); 
 		map.setImage(map.getImage().getScaledInstance(mapX,mapY,Image.SCALE_DEFAULT)); 
 		JLabel mapl=new JLabel(map); 
 		JScrollPane maps=new JScrollPane(mapl); 
 		subp1.add(maps); 
 		
	 
 		// hotel contact information panel 
 		JPanel subp2=new JPanel(); 
 		subp2.setOpaque(false); 
 		subp2.setLayout(new GridLayout(3,1,20,10)); 
 		for(int i=0; i<hotel_info.length;i++){ 
 			JLabel l2=new JLabel(hotel_info[i]); 
 			l2.setForeground(Color.WHITE); 
 			l2.setFont(new Font("Noteworthy", Font.ITALIC,18)); 
 			l2.setHorizontalAlignment(JLabel.TRAILING); 
 			subp2.add(l2); 
 		} 
 	 
 
 
 		p3.add(subp1); 
 		p3.add(subp2); 
 		c.add(BorderLayout.SOUTH,p3); 
 		setSize(1300,700); 
 		//setResizable(false); 
 		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
 		setVisible(true); 
	}	 
	 
	public String setf2(){
		return s;
	}

	public String setf3(){
		return s1;
	}
 
 	public static void main(String[] args) { 
 		HomePage homepage = new HomePage(); 
 		
 	}  
 
 } 

